/** 页面与后台共同报告的构建标识，区分磁盘源码和运行中的旧模块。 */
export const DISTILL_BUILD = '0.19.4-20261127'
export const DISTILL_API_VERSION = 3
